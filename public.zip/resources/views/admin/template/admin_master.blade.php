@include('admin.include.header')
    @yield('content')
@include('admin.include.footer')
@yield('script')