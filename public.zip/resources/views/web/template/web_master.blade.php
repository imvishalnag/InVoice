@include('web.include.header')
 @yield('content')
@include('web.include.footer')
@yield('script')
