
@extends('web.template.web_master')

@section('content')

    <section class="block-wrapper no-sidebar">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    
                    <div class="single-post">
                        
                        <div class="post-title-area">
                            <h2 class="post-title">
                                Netcix cuts out the chill with an integrated personal trainer on running
                            </h2>
                        </div><!-- Post title end -->

                        <div class="post-content-area">
                            <div class="entry-content">
                                <p>Pityful a rethoric question ran over her cheek When she reached the first hills of the Italic Mountains, she had a last view back on the skyline of her hometown Bookmarksgrove, the headline of Alphabet Village and the subline of her own road, the Line Lane.</p>

                                <p>Throw myself down teems with vapour around me, and the meridian sun strikes the upper surface of the impenetrable foliage of my trees, and but a few stray gleams steal into the inner sanctuary grow familiar with the countless indescribable forms of the insects and flies, then I feel the presence of the Almighty, who formed us in his own image, and the breath</p>

                                <blockquote>A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart. I am alone and feel the charm of existence.</blockquote>

                                <p>Lo-fi cred gastropub, brunch aliquip stumptown culpa. Banh mi eiusmod tattooed, freegan Schlitz master cleanse pug. Eu 8-bit id PBR Pinterest taxidermy, swag church-key Echo Park commodo yr. Adipisicing leggings enim laboris wayfarers, cliche Carles placeat typewriter mixtape cold-pressed. Etsy Pitchfork Austin, selvage beard reprehenderit ea ugh.</p>

                                <p><img src="{{asset('web/images/news/news-details/news-details1.jpg')}}" class="img-fluid" alt=""></p>

                                <p>Pitchfork kitsch plaid forage aliquip, sustainable taxidermy deserunt health goth stumptown cred VHS butcher. Mixtape fap Intelligentsia small batch placeat labore, bitters swag chia Echo Park. Four loko aliquip id, delectus beard Bushwick bespoke Blue Bottle eu keytar veniam ethical High Life pour-over.</p>
                                <h3>When, while the lovely valley teems with vapour around me, and the meridian sun strikes.</h3>
                                <p>Art party photo booth deserunt exercitation plaid squid. Minim Austin 3 wolf moon scenester aesthetic, umami odio pariatur bitters. Pop-up occaecat taxidermy street art, tattooed beard literally duis photo booth Thundercats shabby chic. Velit non seitan, tilde art party minim Thundercats viral.  Farm-to-table selfies labore, leggings cupidatat sunt taxidermy umami fanny pack typewriter hoodie art party voluptate cardigan banjo. Listicle meditation paleo, drinking vinegar sint direct trade vegan 3 wolf moon.</p>
                                <h3>Farm-to-table selfies labore leggings:</h3>
                                <ul>
                                <li>Plaid fashion axe semiotics skateboard</li>
                                <li>Mixtape fap Intelligentsia small batch placeat labore</li>
                                <li>Gleams steal into the inner sanctuary grow</li>
                                <li>Like these sweet mornings of spring which</li>
                                </ul>
                                <p>High Life tempor retro Truffaut. Tofu mixtape twee, assumenda quinoa flexitarian aesthetic artisan vinyl pug. Chambray et Carles Thundercats cardigan actually, magna bicycle rights. Plaid fashion axe semiotics skateboard, try-hard food truck aesthetic biodiesel exercitation. Accusamus VHS Wes Anderson Banksy food truck vero.</p>

                            </div><!-- Entery content end -->

                        </div><!-- Share items end -->

                    </div><!-- Single post end -->

                </div><!-- Content Col end -->

            </div><!-- Row end -->
        </div><!-- Container end -->
    </section><!-- First block end -->

@endsection