@include('as.include.header')
 @yield('content')
@include('as.include.footer')
@yield('script')
