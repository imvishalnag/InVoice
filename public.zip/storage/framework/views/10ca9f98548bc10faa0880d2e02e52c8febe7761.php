        <!-- footer content -->
        <footer>
            <div class="pull-right">
              Powered By <a href="https://webinfotech.co.in">Web Infotech</a>
            </div>
            <div class="clearfix"></div>
          </footer>
          <!-- /footer content -->
        </div>
      </div>
  
      <!-- jQuery -->
      <script src="<?php echo e(asset('vendors/jquery/dist/jquery.min.js')); ?>"></script>
      <!-- Bootstrap -->
      <script src="<?php echo e(asset('vendors/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
      <!-- FastClick -->
      <script src="<?php echo e(asset('vendors/fastclick/lib/fastclick.js')); ?>"></script>
      <!-- NProgress -->
      <script src="<?php echo e(asset('vendors/nprogress/nprogress.js')); ?>"></script>
      <!-- Chart.js -->
      <script src="<?php echo e(asset('vendors/Chart.js/dist/Chart.min.js')); ?>"></script>
      <!-- gauge.js -->
      <script src="<?php echo e(asset('vendors/gauge.js/dist/gauge.min.js')); ?>"></script>
      <!-- bootstrap-progressbar -->
      <script src="<?php echo e(asset('vendors/bootstrap-progressbar/bootstrap-progressbar.min.js')); ?>"></script>
      <!-- iCheck -->
      <script src="<?php echo e(asset('vendors/iCheck/icheck.min.js')); ?>"></script>
      <!-- Skycons -->
      <script src="<?php echo e(asset('vendors/skycons/skycons.js')); ?>"></script>
      <!-- Flot -->
      <script src="<?php echo e(asset('vendors/Flot/jquery.flot.js')); ?>"></script>
      <script src="<?php echo e(asset('vendors/Flot/jquery.flot.pie.js')); ?>"></script>
      <script src="<?php echo e(asset('vendors/Flot/jquery.flot.time.js')); ?>"></script>
      <script src="<?php echo e(asset('vendors/Flot/jquery.flot.stack.js')); ?>"></script>
      <script src="<?php echo e(asset('vendors/Flot/jquery.flot.resize.js')); ?>"></script>
      <!-- Flot plugins -->
      <script src="<?php echo e(asset('vendors/flot.orderbars/js/jquery.flot.orderBars.js')); ?>"></script>
      <script src="<?php echo e(asset('vendors/flot-spline/js/jquery.flot.spline.min.js')); ?>"></script>
      <script src="<?php echo e(asset('vendors/flot.curvedlines/curvedLines.js')); ?>"></script>
      <!-- DateJS -->
      <script src="<?php echo e(asset('vendors/DateJS/build/date.js')); ?>"></script>
      <!-- JQVMap -->
      <script src="<?php echo e(asset('vendors/jqvmap/dist/jquery.vmap.js')); ?>"></script>
      <script src="<?php echo e(asset('vendors/jqvmap/dist/maps/jquery.vmap.world.js')); ?>"></script>
      <script src="<?php echo e(asset('vendors/jqvmap/examples/js/jquery.vmap.sampledata.js')); ?>"></script>
      <!-- bootstrap-daterangepicker -->
      <script src="<?php echo e(asset('vendors/moment/min/moment.min.js')); ?>"></script>
      <script src="<?php echo e(asset('vendors/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
  
      <!-- Custom Theme Scripts -->
      <script src="<?php echo e(asset('build/js/custom.min.js')); ?>"></script>

      <script src="<?php echo e(asset('vendors/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
      <script src="<?php echo e(asset('vendors/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
      <script src="<?php echo e(asset('vendors/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
      
    </body>
  </html><?php /**PATH E:\xampp\htdocs\invoice\resources\views/admin/include/footer.blade.php ENDPATH**/ ?>